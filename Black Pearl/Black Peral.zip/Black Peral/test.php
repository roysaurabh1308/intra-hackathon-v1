<head>
<style>

.inline-border{
	border: 2px solid green;
} 
}
</style>
</head>

<?php

$myfile = fopen("chatbox.txt", "r") or die("Unable to open file!");
		$readdata = fread($myfile,filesize("chatbox.txt"));
		$str_arr=explode(";",$readdata);
		$arrlength=count($str_arr);
		for($x = 0; $x < $arrlength; $x++) {
			$s="";
			if($x%2==0)
			{
				$s="align='right'";
			}
		echo "<div ".$s."><span class='inline-border'><b>";
		echo $str_arr[$x];
		echo "</b></span></div>";
		echo "<br>";
		}
		fclose($myfile);

?>

<meta http-equiv=refresh content="3.0">