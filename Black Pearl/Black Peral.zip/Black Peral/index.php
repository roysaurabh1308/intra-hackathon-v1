<br><br>
<center>
<h1>जनहित में जारी....</h1>
<?php
	if(isset($_POST['upload'])){
		echo "Hello";
		$file_name=$_FILES['file']['name'];
		$file_type=$_FILES['file']['type'];
		$file_size=$_FILES['file']['size'];
		$file_temp=$_FILES['file']['tmp_name'];
		$un=$_POST['user'];
		$newn=$un."_".$file_name;
		echo $newn;
		$file_store="upload/".$newn;
		$pass=$_POST['pins'];
		if($pass!='4532')
		{
			echo "<br><h1><font color='red'>OOps wrong pin...</font></h1>";
		}
		else{
		
		move_uploaded_file($file_temp,$file_store);
		echo "<br>Successfully uploaded...<br><br>Contributed by:-<b><i>";
		echo $_POST['user'];
		echo "</i></b><br><br><br>";
		}
	}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Upload</title>
</head>
<body>
<br>
<!--a href="/images">Access to your items....</a-->
<a href="/upload">यहाँ  जाएँ......</a>
<br>
<form action="?" method="POST" enctype="multipart/form-data">
	<label>Uploading files</label>
	<p><input type="file" name="file"/></p>
	<p><input type="submit" name="upload" value="Upload फाईल.."/></p>
	<p>Username</p>
	<input type="text" name="user"/>
	<p>Pin</p>
	<input type="password" name="pins"/>
</form>
<br><a href="chat.php">Open chat</a>
</body>
</html>
</center>