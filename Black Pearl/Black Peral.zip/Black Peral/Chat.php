
<?php
	if(isset($_POST['sdata'])){
		
		$tm=$_POST['inbox'];
		$txt=$tm.";";
		$myfile = fopen("chatbox.txt", "a") or die("Something went Wrong!");
		fwrite($myfile,$txt);
		fclose($myfile);


		
	}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Upload</title>
</head>
<body>

<br>

<form action="?" method="POST" enctype="multipart/form-data">
	<p>Chat</p>
	<input type="text" name="inbox"/>
	<p><input type="submit" name="sdata" value="Send"/></p>
	
</form>
<center>
<iframe src="test.php" height="500" width="20%" scrolling="yes"/>
</center>
</body>
</html>
